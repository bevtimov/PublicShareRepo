﻿using System;
using System.Collections.Generic;
using WildFarm.Factories;
using WildFarm.IO;
using WildFarm.Models.Interfaces;

namespace WildFarm.Core
{
    class Engine : IEngine
    {
        private readonly IReader reader;
        private readonly IWriter writer;
        private readonly IFoodFactory foodFactory;
        private readonly IAnimalFactory animalFactory;

        public Engine(IReader reader, IWriter writer, IAnimalFactory animalFactory, IFoodFactory foodFactory)
        {
            this.reader = reader;
            this.writer = writer;
            this.animalFactory = animalFactory;
            this.foodFactory = foodFactory;

        }

        public void Run()
        {

            int inputNumber = 0;
            List<IAnimal> animals = new List<IAnimal>();
            IAnimal animal = null;
            IFood food = null;
            string input;
            
            while ((input = reader.CustomReadLine()) != "End")
            {
                string[] inputArgs = input.Split();

                try
                {

                    if (inputNumber % 2 == 0)
                    {
                        string animalType = inputArgs[0];
                        string name = inputArgs[1];
                        double weight = double.Parse(inputArgs[2]);

                        switch (animalType)
                        {
                            case "Cat":
                                string livingRegion = inputArgs[3];
                                string breed = inputArgs[4];
                                animal = animalFactory.CreateCat(name, weight, livingRegion, breed);
                                animals.Add(animal);
                                break;

                            case "Tiger":
                                livingRegion = inputArgs[3];
                                breed = inputArgs[4];
                                animal = animalFactory.CreateTiger(name, weight, livingRegion, breed);
                                animals.Add(animal);
                                break;
                            case "Dog":
                                livingRegion = inputArgs[3];
                                animal = animalFactory.CreateDog(name, weight, livingRegion);
                                animals.Add(animal);
                                break;
                            case "Mouse":
                                livingRegion = inputArgs[3];
                                animal = animalFactory.CreateMouse(name, weight, livingRegion);
                                animals.Add(animal);
                                break;
                            case "Owl":
                                double wingSpan = double.Parse(inputArgs[3]);
                                animal = animalFactory.CreateOwl(name, weight, wingSpan);
                                animals.Add(animal);
                                break;
                            case "Hen":
                                wingSpan = double.Parse(inputArgs[3]);
                                animal = animalFactory.CreateHen(name, weight, wingSpan);
                                animals.Add(animal);
                                break;

                            default:
                                throw new ArgumentException("Invalid animal input!");
                        }
                    }

                    else
                    {

                        string foodType = inputArgs[0];
                        int foodQuantity = int.Parse(inputArgs[1]);

                        switch (foodType)
                        {
                            case "Meat":
                                food = foodFactory.CreateMeat(foodQuantity);
                                break;
                            case "Vegetable":
                                food = foodFactory.CreateVegetable(foodQuantity);
                                break;
                            case "Seeds":
                                food = foodFactory.CreateSeeds(foodQuantity);
                                break;
                            case "Fruit":
                                food = foodFactory.CreateFruit(foodQuantity);
                                break;

                            default:
                                throw new ArgumentException("Invalid food input!");
                        }

                    }
                }
                catch (Exception e)
                {

                    writer.CustomWriteLine(e.Message);
                }

                if (inputNumber % 2 != 0)
                {
                    writer.CustomWriteLine(animal.AskForFood());
                    try
                    {
                        
                        animal.Eat(food);

                    }
                    catch (Exception e)
                    {
                        writer.CustomWriteLine(e.Message);
                    }

                }

                inputNumber++;
            }

            foreach (var item in animals)
            {
                writer.CustomWriteLine(item.ToString());
            }

        }
    }
}
