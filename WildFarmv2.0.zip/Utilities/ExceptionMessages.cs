﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Utilities
{
   public static class ExceptionMessages
    {
        public const string InvalidFood = "{0} does not eat {1}!";


    }
}
