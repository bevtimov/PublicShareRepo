﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Models.Classes.Food;
using WildFarm.Models.Interfaces;

namespace WildFarm.Factories
{
    class FoodFactory : IFoodFactory
    {
        public Fruit CreateFruit(int quantity)
        {
            return new Fruit(quantity);
        }

        public Meat CreateMeat(int quantity)
        {
            return new Meat(quantity);
        }

        public Seeds CreateSeeds(int quantity)
        {
            return new Seeds(quantity);
        }

        public Vegetable CreateVegetable(int quantity)
        {
            return new Vegetable(quantity);
        }
    }
}
