﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Models.Classes.Animals.Birds;
using WildFarm.Models.Classes.Animals.Mammals;
using WildFarm.Models.Classes.Animals.Mammals.Felines;
using WildFarm.Models.Interfaces;

namespace WildFarm.Factories
{
    public class AnimalFactory : IAnimalFactory
    {
        
        public Cat CreateCat(string name, double weight, string livingRegion, string breed)
        {
            return new Cat(name,weight,livingRegion,breed);
            
        }

        public Dog CreateDog(string name, double weight, string livingRegion)
        {
            return new Dog(name,weight,livingRegion);
        }

        public Hen CreateHen(string name, double weight, double wingSize)
        {
            return new Hen(name, weight, wingSize);
        }

        public Mouse CreateMouse(string name, double weight, string livingRegion)
        {
            return new Mouse(name, weight, livingRegion);
        }

        public Owl CreateOwl(string name, double weight, double wingSize)
        {
            return new Owl(name, weight, wingSize);
        }

        public Tiger CreateTiger(string name, double weight, string livingRegion, string breed)
        {
            return new Tiger(name, weight, livingRegion, breed);
        }

    }
}
