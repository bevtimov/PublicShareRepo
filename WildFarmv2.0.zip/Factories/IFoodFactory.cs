﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Models.Classes.Food;

namespace WildFarm.Factories
{
 public   interface IFoodFactory
    {

        public Vegetable CreateVegetable(int quantity);
        public Meat CreateMeat(int quantity);
        public Seeds CreateSeeds(int quantity);
        public Fruit CreateFruit(int quantity);



    }
}
