﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Models.Classes.Animals.Birds;
using WildFarm.Models.Classes.Animals.Mammals;
using WildFarm.Models.Classes.Animals.Mammals.Felines;

namespace WildFarm.Factories
{
  public  interface IAnimalFactory
    {
        public Cat CreateCat(string name, double weight, string livingRegion, string breed);
        public Tiger CreateTiger(string name, double weight, string livingRegion, string breed);

        public Dog CreateDog(string name, double weight, string livingRegion);

        public Hen CreateHen(string name, double weight, double wingSize);

        public Owl CreateOwl(string name, double weight, double wingSize);

        public Mouse CreateMouse(string name, double weight, string livingRegion);





    }
}
