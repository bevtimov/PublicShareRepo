﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Models.Interfaces;
using WildFarm.Utilities;

namespace WildFarm.Models.Classes.Animals.Mammals
{
    public class Mouse : Mammal
    {
        public Mouse(string name, double weight, string livingRegion) : base(name, weight, livingRegion)
        {
        }

        public override string AskForFood()
        {
            return $"Squeak";
        }

        public override void Eat(IFood food)
        {
            string foodType = food.GetType().Name;
            if (Enum.IsDefined(typeof(MouseFoodList), foodType))
            {
                this.FoodEaten = food.Quantity;
                this.Weight += FoodEaten * 0.10;
            }
            else
            {
                throw new ArgumentException($"{GetType().Name} does not eat {foodType}!");
            }


        }

        public override string ToString()
        {
            return $"{GetType().Name} [{this.Name}, {this.Weight}, {this.LivingRegion}, {this.FoodEaten}]";
        }
    }
}
