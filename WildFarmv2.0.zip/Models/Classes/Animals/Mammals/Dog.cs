﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Models.Classes.Food;
using WildFarm.Models.Interfaces;
using WildFarm.Utilities;

namespace WildFarm.Models.Classes.Animals.Mammals
{
    public class Dog : Mammal
    {
        public Dog(string name, double weight, string livingRegion) : base(name, weight, livingRegion)
        {
        }

        public override string AskForFood()
        {
            return $"Woof!";
        }

        public override void Eat(IFood food)
        {
            
            string foodType = food.GetType().Name;

            if (Enum.IsDefined(typeof(DogFoodList),foodType))
            {
                this.FoodEaten = food.Quantity;
                this.Weight += FoodEaten * 0.40;
            }
            else
            {
                throw new ArgumentException($"{GetType().Name} does not eat {foodType}!");
            }

        }

        public override string ToString()
        {
            return $"{GetType().Name} [{this.Name}, {this.Weight}, {this.LivingRegion}, {this.FoodEaten}]";

        }
    }
}
