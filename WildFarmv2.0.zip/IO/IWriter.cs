﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.IO
{
 public  interface IWriter
    {

        public void CustomWrite(string text);

        public void CustomWriteLine(string text);



    }
}
