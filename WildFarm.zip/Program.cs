﻿using WildFarm.Core;
using WildFarm.Factories;
using WildFarm.IO;
using WildFarm.Models.Classes.Animals;
using WildFarm.Models.Classes.Food;

namespace WildFarm
{
    class Program
    {
        static void Main(string[] args)
        {

            IReader reader = new ConsoleReader();
            IWriter writer = new ConsoleWriter();
            IFoodFactory foodFactory = new FoodFactory();
            IAnimalFactory animalfactory = new AnimalFactory();
            IEngine engine = new Engine(reader,writer,animalfactory,foodFactory);

            engine.Run();

          

        }
    }
}
