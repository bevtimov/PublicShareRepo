﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Models.Interfaces;
using WildFarm.Utilities;

namespace WildFarm.Models.Classes.Animals.Mammals.Felines
{
    public class Cat : Feline
    {
        public Cat(string name, double weight, string livingRegion, string breed) : base(name, weight, livingRegion, breed)
        {
        }

        public override string AskForFood()
        {
            return $"Meow";
        }

        public override void Eat(IFood food)
        {
            
            string foodType = food.GetType().Name;

            if (Enum.IsDefined(typeof(CatFoodList), foodType))
            {
                this.FoodEaten = food.Quantity;
                this.Weight += FoodEaten*0.30;
                
            }
            else
            {
                throw new ArgumentException($"{GetType().Name} does not eat {foodType}!");
            }

            
        }
    }
}
