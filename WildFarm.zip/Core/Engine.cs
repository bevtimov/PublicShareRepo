﻿using System;
using System.Collections.Generic;
using WildFarm.Factories;
using WildFarm.IO;
using WildFarm.Models.Interfaces;

namespace WildFarm.Core
{
    class Engine : IEngine
    {
        private readonly IReader reader;
        private readonly IWriter writer;
        private readonly IFoodFactory foodFactory;
        private readonly IAnimalFactory animalFactory;

        public Engine(IReader reader, IWriter writer, IAnimalFactory animalFactory, IFoodFactory foodFactory)
        {
            this.reader = reader;
            this.writer = writer;
            this.animalFactory = animalFactory;
            this.foodFactory = foodFactory;

        }

        public void Run()
        {

            string input = reader.CustomReadLine();
            List<IAnimal> animals = new List<IAnimal>();
            IAnimal animal = null;
            IFood food = null;


            while (input != "End")
            {

                string[] inputArgs = input.Split();
                string animalType = inputArgs[0];
                string name = inputArgs[1];
                double weight = double.Parse(inputArgs[2]);


                try
                {
                    switch (animalType)
                    {
                        case "Cat":
                            string livingRegion = inputArgs[3];
                            string breed = inputArgs[4];
                            animal = animalFactory.CreateCat(name, weight, livingRegion, breed);
                            animals.Add(animal);
                            break;

                        case "Tiger":
                            livingRegion = inputArgs[3];
                            breed = inputArgs[4];
                            animal = animalFactory.CreateTiger(name, weight, livingRegion, breed);
                            animals.Add(animal);
                            break;
                        case "Dog":
                            livingRegion = inputArgs[3];
                            animal = animalFactory.CreateDog(name, weight, livingRegion);
                            animals.Add(animal);
                            break;
                        case "Mouse":
                            livingRegion = inputArgs[3];
                            animal = animalFactory.CreateMouse(name, weight, livingRegion);
                            animals.Add(animal);
                            break;
                        case "Owl":
                            double wingSpan = double.Parse(inputArgs[3]);
                            animal = animalFactory.CreateOwl(name, weight, wingSpan);
                            animals.Add(animal);
                            break;
                        case "Hen":
                            wingSpan = double.Parse(inputArgs[3]);
                            animal = animalFactory.CreateHen(name, weight, wingSpan);
                            animals.Add(animal);
                            break;

                        default:
                            throw new ArgumentException("Invalid animal input!");
                    }
                }
                catch (Exception e)
                {
                    writer.CustomWriteLine(e.Message);

                }



                string foodInput = reader.CustomReadLine();
                string[] foodArgs = foodInput.Split();
                string foodType = foodArgs[0];
                int foodQuantity = int.Parse(foodArgs[1]);
                try
                {
                    switch (foodType)
                    {
                        case "Meat":
                            food = foodFactory.CreateMeat(foodQuantity);
                            break;
                        case "Vegetable":
                            food = foodFactory.CreateVegetable(foodQuantity);
                            break;
                        case "Seeds":
                            food = foodFactory.CreateSeeds(foodQuantity);
                            break;
                        case "Fruit":
                            food = foodFactory.CreateFruit(foodQuantity);
                            break;

                        default:
                            throw new ArgumentException("Invalid food input!");
                    }
                }
                catch (Exception e)
                {
                    writer.CustomWriteLine(e.Message);
                }


                writer.CustomWriteLine(animal.AskForFood());
                animal.Eat(food);



                input = reader.CustomReadLine();
            }

            foreach (var item in animals)
            {
                writer.CustomWriteLine(item.ToString());
            }

        }
    }
}
